﻿namespace atividadesAOO
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Nome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DataNascimento = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Cpf = new System.Windows.Forms.TextBox();
            this.textbox = new System.Windows.Forms.Label();
            this.RG = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(124, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome Completo:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Nome
            // 
            this.Nome.Location = new System.Drawing.Point(253, 104);
            this.Nome.Name = "Nome";
            this.Nome.Size = new System.Drawing.Size(268, 27);
            this.Nome.TabIndex = 1;
            this.Nome.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(120, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Data Nascimento:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // DataNascimento
            // 
            this.DataNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DataNascimento.Location = new System.Drawing.Point(253, 241);
            this.DataNascimento.Name = "DataNascimento";
            this.DataNascimento.Size = new System.Drawing.Size(122, 27);
            this.DataNascimento.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(377, 283);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 25);
            this.button1.TabIndex = 4;
            this.button1.Text = "Executar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(212, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Cpf:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Cpf
            // 
            this.Cpf.Location = new System.Drawing.Point(253, 149);
            this.Cpf.Name = "Cpf";
            this.Cpf.Size = new System.Drawing.Size(268, 27);
            this.Cpf.TabIndex = 6;
            // 
            // textbox
            // 
            this.textbox.AutoSize = true;
            this.textbox.Location = new System.Drawing.Point(216, 205);
            this.textbox.Name = "textbox";
            this.textbox.Size = new System.Drawing.Size(31, 20);
            this.textbox.TabIndex = 7;
            this.textbox.Text = "RG:";
            this.textbox.Click += new System.EventHandler(this.RG_Click);
            // 
            // RG
            // 
            this.RG.Location = new System.Drawing.Point(253, 198);
            this.RG.Name = "RG";
            this.RG.Size = new System.Drawing.Size(268, 27);
            this.RG.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.RG);
            this.Controls.Add(this.textbox);
            this.Controls.Add(this.Cpf);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.DataNascimento);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Nome);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Cadastro de Pessoas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private TextBox Nome;
        private Label label2;
        private DateTimePicker DataNascimento;
        private Button button1;
        private Label label3;
        private TextBox Cpf;
        private Label textbox;
        private TextBox RG;
    }
}