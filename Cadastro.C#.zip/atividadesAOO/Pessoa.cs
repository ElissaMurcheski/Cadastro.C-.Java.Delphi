﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace atividades1
{
    public class Pessoa
    {
        public string? Nome { get; set; }
        public DateTime DataNascimento { get; set; }
        public Int64 Cpf { get; set; }
        public int RG { get; set; }

        private int retornarIdade()
        {
           int minhaidade = DateTime.Now.Year - DataNascimento.Year;
           if (DateTime.Now.DayOfYear < DataNascimento.DayOfYear)
            {
              minhaidade = minhaidade - 1;
                }
              return minhaidade;
            }

        public string detalharPessoa()
        {

            return "Informações do cliente: \nNome Completo: " + Nome + " \nIdade: " + retornarIdade() +
                " anos \nCPF: " + Cpf + "\nRG: " + RG;
        }
    }
}

