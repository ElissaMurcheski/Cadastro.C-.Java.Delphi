using atividades1;

namespace atividadesAOO
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Pessoa objpessoa = new Pessoa();
            objpessoa.Nome = Nome.Text;
            objpessoa.DataNascimento = DataNascimento.Value;
            objpessoa.Cpf = Convert.ToInt64(Cpf.Text);
            objpessoa.RG = Convert.ToInt32(RG.Text);

            MessageBox.Show(objpessoa.detalharPessoa());

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void RG_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}