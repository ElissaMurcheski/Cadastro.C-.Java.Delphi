
package com.mycompany.atividadejavaaoo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

public class AtividadejavaAOO {

    public static void main(String[] args) throws ParseException {
       //Declaração das variaveis para receber os valores
      //digitados pelo usuário
      String nome;
      Date dataNascimento;
      Long cpf;
      int rg;

      //Atribuindo os valores digitados as minhas variaves.
      SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
      nome = JOptionPane.showInputDialog("Nome Completo:");
      cpf = Long.parseLong(JOptionPane.showInputDialog("CPF: "));
      rg = Integer.parseInt(JOptionPane.showInputDialog("RG: "));
      dataNascimento =  sdf.parse(JOptionPane.showInputDialog("Data Nascimento: "));
      //Criar um Objeto do tipo Pessoa
      
      Pessoa objPes;
      //Instanciar Objeto Pessoa
      objPes = new Pessoa();
      //substituição -> Pessoa objPes = new Pessoa();
      PessoaDao objPessoaDao = new PessoaDao();
      
      //Atribuir osa valroes das variaveis ao objeto pessoa
      objPes.setNome(nome);
      objPes.setCpf(cpf);
      objPes.setDataNascimento(dataNascimento);
      objPes.setRg(rg);
      objPessoaDao.inserirPessoa(objPes);
      
      JOptionPane.showMessageDialog(null, objPes.detalharPessoa());
      
     // JOptionPane.showMessageDialog(null, retornoDao);
    }
}
