package com.mycompany.atividadejavaaoo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class Pessoa {
    private String nome;
    private Date dataNascimento;
    private long cpf;
    private int rg;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public long getCpf() {
        return cpf;
    }

    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    public int getRg() {
        return rg;
    }

    public void setRg(int rg) {
        this.rg = rg;
    }
    
    private int retornarIdade() {
        Calendar dataniver = new GregorianCalendar();
        dataniver.setTime(dataNascimento);
        Calendar calendario = Calendar.getInstance();
        int idade = calendario.get(Calendar.YEAR) - dataniver.get(Calendar.YEAR);
        dataniver.add(Calendar.YEAR, idade);
            if (calendario.before(dataniver)){
                idade --;
            }
        return  idade;
    }
    
    public String detalharPessoa() {
        return "Informações do cliente: \nNome Completo: " + nome + "\nIdade: " + retornarIdade() +
                " anos" + "\nCPF: " + cpf + "\nRG: " + rg; 
    }
    
}

