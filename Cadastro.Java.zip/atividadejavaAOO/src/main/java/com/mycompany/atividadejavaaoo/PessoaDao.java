
package com.mycompany.atividadejavaaoo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class PessoaDao {
    private String user = "root";
    private String password = "root";
    private String url = "jdbc:mysql://localhost:3306/elissamurcheski?allowPublicKeyRetrieval=true&useSSL=false";
    //jdbc:mysql://localhost:3306/"+base;
    private Connection con = null; 
    private String driver = "com.mysql.cj.jdbc.Driver";
   
    public Connection conectarBanco() {
        try{
             Class.forName(driver);
        con = (Connection) DriverManager.getConnection(this.url, this.user, this.password);
         } catch (SQLException e) {
             System.err.print(e);
             JOptionPane.showMessageDialog(null, "error");
         } catch (ClassNotFoundException ex) {
             Logger.getLogger(PessoaDao.class.getName()).log(Level.SEVERE, null, ex);
         }
        return con;
    }

    public void desconectarBanco() {
        try{
            con.close();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }
    
    public boolean inserirPessoa(Pessoa pes){
        PreparedStatement ps = null;
        con = conectarBanco();
        String sql = "INSERT INTO pessoa (nome_completo, data_Nascimento, cpf, rg) VALUES(?,?,?,?)";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1, pes.getNome());
            ps.setDate(2, new Date(pes.getDataNascimento().getTime()));
            ps.setLong(3, pes.getCpf());
            ps.setInt(4, pes.getRg());
            ps.execute();
            desconectarBanco();
            return true;
        }catch (SQLException e)    
        {
            desconectarBanco(); 
            System.err.println(e);
            return false; 
        }  
    }
}